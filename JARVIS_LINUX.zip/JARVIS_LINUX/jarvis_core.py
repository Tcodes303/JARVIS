import tkinter as tk
from tkinter import scrolledtext, messagebox
import threading
import speech_recognition as sr
import pyttsx3
import google.generativeai as genai
import re
import time

# === Offline TTS setup ===
engine = pyttsx3.init()  # Linux usually auto-detects espeak
engine.setProperty("rate", 150)

def speak(text: str):
    engine.say(text)
    engine.runAndWait()

# === Gemini AI setup ===
API_KEY = "YOUR_API_KEY_HERE"  # placeholder
MODEL_NAME = "gemini-2.0-flash"

try:
    genai.configure(api_key=API_KEY)
    gemini_model = genai.GenerativeModel(MODEL_NAME)
except Exception as e:
    gemini_model = None
    print(f"Failed to initialize Gemini: {e}")

# === Limit responses to 5 sentences ===
def truncate_response(text: str, full=False):
    if full:
        return text
    sentences = re.split(r'(?<=[.!?]) +', text)
    return " ".join(sentences[:5])

# === AI request, always English personality ===
def ask_ai(prompt: str, full=False):
    if not gemini_model:
        return "No Gemini model available. Check your API key."
    full_prompt = f"""
You are Jarvis, an AI assistant.
Always respond in English, regardless of the user's input language.
Be concise and clear unless the user requests longer responses.
User question: {prompt}
"""
    try:
        response = gemini_model.generate_content(full_prompt)
        text = response.text if response and hasattr(response, "text") else "No answer."
        return truncate_response(text, full)
    except Exception as e:
        return f"Error: {e}"

# === Speech recognition ===
def listen_and_recognize():
    recognizer = sr.Recognizer()
    mics = sr.Microphone.list_microphone_names()
    if not mics:
        return "No microphone found."

    for i, _ in enumerate(mics):
        try:
            with sr.Microphone(device_index=i) as source:
                recognizer.adjust_for_ambient_noise(source, duration=1)
                audio = recognizer.listen(source, timeout=5, phrase_time_limit=8)
                return recognizer.recognize_google(audio, language="en-US")
        except Exception:
            continue
    return "Error accessing microphone."

# === Chat with typing + TTS ===
def send_message(user_input):
    if not user_input:
        return

    chat_window.config(state="normal")
    chat_window.insert(tk.END, f"You: {user_input}\n", "user")
    chat_window.config(state="disabled")
    chat_window.see(tk.END)
    input_entry.delete(0, tk.END)

    def worker():
        response = ask_ai(user_input)
        chat_window.config(state="normal")
        chat_window.insert(tk.END, "Jarvis: ", "jarvis")
        chat_window.config(state="disabled")
        for char in response:
            chat_window.config(state="normal")
            chat_window.insert(tk.END, char)
            chat_window.config(state="disabled")
            chat_window.see(tk.END)
            time.sleep(0.03)
        chat_window.config(state="normal")
        chat_window.insert(tk.END, "\n\n")
        chat_window.config(state="disabled")
        chat_window.see(tk.END)
        speak(response)

    threading.Thread(target=worker, daemon=True).start()

def start_listening():
    def worker():
        chat_window.config(state="normal")
        chat_window.insert(tk.END, "🎙️ Listening...\n", "system")
        chat_window.config(state="disabled")
        chat_window.see(tk.END)

        text = listen_and_recognize()
        if not text or "Error" in text:
            messagebox.showerror("Error", text)
            return
        send_message(text)

    threading.Thread(target=worker, daemon=True).start()

# === GUI ===
def main():
    global chat_window, input_entry

    root = tk.Tk()
    root.title("Jarvis - Gemini Interface (Linux)")
    root.geometry("700x500")
    root.configure(bg="black")

    title = tk.Label(root, text="Jarvis Voice Interface (Gemini)",
                     font=("Helvetica", 16, "bold"), fg="cyan", bg="black")
    title.pack(pady=10)

    chat_window = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=80, height=20,
                                            font=("Helvetica", 12), bg="black", fg="white")
    chat_window.pack(padx=10, pady=10)
    chat_window.tag_config("user", foreground="lightgreen")
    chat_window.tag_config("jarvis", foreground="cyan")
    chat_window.tag_config("system", foreground="orange")
    chat_window.config(state="disabled")

    input_frame = tk.Frame(root, bg="black")
    input_frame.pack(pady=5)

    input_entry = tk.Entry(input_frame, font=("Helvetica", 12), width=50)
    input_entry.pack(side="left", padx=5)

    send_button = tk.Button(input_frame, text="Send", command=lambda: send_message(input_entry.get()),
                            font=("Helvetica", 12), bg="darkcyan", fg="white")
    send_button.pack(side="left", padx=5)

    listen_button = tk.Button(root, text="🎙️ Voice Input", command=start_listening,
                              font=("Helvetica", 14), bg="darkred", fg="white")
    listen_button.pack(pady=10)

    root.mainloop()
