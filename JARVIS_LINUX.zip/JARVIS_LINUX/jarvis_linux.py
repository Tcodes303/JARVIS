from jarvis_core import main

if __name__ == "__main__":
    print("Starting J.A.R.V.I.S. (Linux Edition)")
    main()
